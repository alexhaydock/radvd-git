#!/bin/sh

autoreconf -vif

